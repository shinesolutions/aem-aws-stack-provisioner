#!/usr/bin/env bash

echo 'Running Post Configuration Script'

sudo apache2ctl -k graceful

