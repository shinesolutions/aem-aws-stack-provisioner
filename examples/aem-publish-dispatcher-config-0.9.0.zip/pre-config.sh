#!/usr/bin/env bash

echo 'Running Pre Configuration Script'

